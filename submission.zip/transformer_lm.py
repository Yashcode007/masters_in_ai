# models.py

import numpy as np
import torch
import torch.nn as nn
import math
from torch import optim


class LanguageModel(object):

    def get_next_char_log_probs(self, context) -> np.ndarray:
        """
        Returns a log probability distribution over the next characters given a context.
        The log should be base e

        NOTE: You should make sure you call model.eval() to determinize inference here (turns off dropout
        layers in TransformerEncoder).
        :param context: the string context that the LM conditions on
        :return: A numpy vector log P(y | context) where y ranges over the output vocabulary.
        """
        raise Exception("Only implemented in subclasses")


    def get_log_prob_sequence(self, next_chars, context) -> float:
        """
        Scores a bunch of characters following context. That is, returns
        log P(nc1, nc2, nc3, ... | context) = log P(nc1 | context) + log P(nc2 | context, nc1), ...
        The log should be base e

        NOTE: You should make sure you call model.eval() to determinize inference here (turns off dropout
        layers in TransformerEncoder).
        :param next_chars:
        :param context:
        :return: The float probability
        """
        raise Exception("Only implemented in subclasses")


class UniformLanguageModel(LanguageModel):
    def __init__(self, voc_size):
        self.voc_size = voc_size

    def get_next_char_log_probs(self, context):
        return np.ones([self.voc_size]) * np.log(1.0/self.voc_size)

    def get_log_prob_sequence(self, next_chars, context):
        return np.log(1.0/self.voc_size) * len(next_chars)


class PositionalEncodingLM(nn.Module):
    """Positional encoding for the language model, supporting batched input."""
    def __init__(self, d_model: int, num_positions: int = 20, batched=True):
        super().__init__()
        self.emb = nn.Embedding(num_positions, d_model)
        self.batched = batched

    def forward(self, x):
        input_size = x.shape[-2]
        indices_to_embed = torch.arange(0, input_size).long()
        if self.batched:
            emb_unsq = self.emb(indices_to_embed).unsqueeze(0)
            return x + emb_unsq
        else:
            return x + self.emb(indices_to_embed)


class TransformerLMModel(nn.Module):
    """
    Transformer-based language model using nn.TransformerEncoder with causal masking.
    Takes indexed characters, embeds them, runs through Transformer, and predicts
    the next character at each position.
    """
    def __init__(self, vocab_size, chunk_size, d_model, nhead, d_hid, nlayers, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.chunk_size = chunk_size
        self.vocab_size = vocab_size

        self.embedding = nn.Embedding(vocab_size, d_model)
        self.pos_encoding = PositionalEncodingLM(d_model, chunk_size, batched=True)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=d_hid,
            dropout=dropout, batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=nlayers)
        self.output_layer = nn.Linear(d_model, vocab_size)
        self.log_softmax = nn.LogSoftmax(dim=-1)

    def forward(self, src):
        """
        :param src: (seq_len,) or (batch_size, seq_len) of token indices
        :return: log probabilities (seq_len, vocab_size) or (batch_size, seq_len, vocab_size)
        """
        if src.dim() == 1:
            src = src.unsqueeze(0)
            squeeze = True
        else:
            squeeze = False

        seq_len = src.shape[1]
        # Causal mask: upper triangle is -inf so tokens cannot attend to future positions
        mask = torch.triu(torch.ones(seq_len, seq_len) * float('-inf'), diagonal=1)

        emb = self.embedding(src) * math.sqrt(self.d_model)
        emb = self.pos_encoding(emb)
        output = self.transformer_encoder(emb, mask=mask)
        output = self.output_layer(output)
        log_probs = self.log_softmax(output)

        if squeeze:
            log_probs = log_probs.squeeze(0)

        return log_probs


class NeuralLanguageModel(LanguageModel):
    def __init__(self, model, vocab_index, chunk_size):
        self.model = model
        self.vocab_index = vocab_index
        self.chunk_size = chunk_size

    def get_next_char_log_probs(self, context):
        self.model.eval()
        with torch.no_grad():
            # Prepend space as start-of-sequence token
            input_str = " " + context
            # Use the last chunk_size characters as the model's context window
            if len(input_str) > self.chunk_size:
                input_str = input_str[-self.chunk_size:]
            indices = [self.vocab_index.index_of(c) for c in input_str]
            input_tensor = torch.LongTensor(indices)
            log_probs = self.model(input_tensor)
            return log_probs[-1].detach().numpy()

    def get_log_prob_sequence(self, next_chars, context):
        self.model.eval()
        log_prob = 0.0
        with torch.no_grad():
            for i in range(len(next_chars)):
                # Build the full context for predicting next_chars[i]
                input_str = " " + context + next_chars[:i]
                if len(input_str) > self.chunk_size:
                    input_str = input_str[-self.chunk_size:]
                indices = [self.vocab_index.index_of(c) for c in input_str]
                input_tensor = torch.LongTensor(indices)
                log_probs = self.model(input_tensor)
                char_idx = self.vocab_index.index_of(next_chars[i])
                log_prob += log_probs[-1, char_idx].item()
        return float(log_prob)


def train_lm(args, train_text, dev_text, vocab_index):
    """
    :param args: command-line args, passed through here for your convenience
    :param train_text: train text as a sequence of characters
    :param dev_text: dev text as a sequence of characters
    :param vocab_index: an Indexer of the character vocabulary (27 characters)
    :return: a NeuralLanguageModel instance trained on the given data
    """
    # Hyperparameters
    chunk_size = 20
    vocab_size = len(vocab_index)
    d_model = 128
    nhead = 4
    d_hid = 256
    nlayers = 2
    dropout = 0.0
    lr = 0.002
    batch_size = 32
    num_epochs = 12

    # Create training chunks: non-overlapping segments of chunk_size characters
    # For each chunk c_0..c_19, input = [space, c_0, ..., c_18], target = [c_0, ..., c_19]
    chunks_input = []
    chunks_target = []
    for i in range(0, len(train_text) - chunk_size + 1, chunk_size):
        chunk = train_text[i:i + chunk_size]
        if len(chunk) < chunk_size:
            break
        # Input: space (SOS) + first (chunk_size - 1) characters of the chunk
        input_str = " " + chunk[:-1]
        target_str = chunk
        input_indices = [vocab_index.index_of(c) for c in input_str]
        target_indices = [vocab_index.index_of(c) for c in target_str]
        chunks_input.append(input_indices)
        chunks_target.append(target_indices)

    input_tensor = torch.LongTensor(chunks_input)    # (num_chunks, chunk_size)
    target_tensor = torch.LongTensor(chunks_target)   # (num_chunks, chunk_size)
    num_chunks = len(chunks_input)
    print("Number of training chunks: %d" % num_chunks)

    # Create model
    model = TransformerLMModel(vocab_size, chunk_size, d_model, nhead, d_hid, nlayers, dropout)
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    loss_fcn = nn.NLLLoss()

    for epoch in range(num_epochs):
        model.train()
        total_loss = 0.0
        perm = torch.randperm(num_chunks)
        for batch_start in range(0, num_chunks, batch_size):
            batch_indices = perm[batch_start:batch_start + batch_size]
            batch_input = input_tensor[batch_indices]     # (batch, chunk_size)
            batch_target = target_tensor[batch_indices]   # (batch, chunk_size)

            optimizer.zero_grad()
            log_probs = model(batch_input)                # (batch, chunk_size, vocab_size)
            loss = loss_fcn(log_probs.reshape(-1, vocab_size), batch_target.reshape(-1))
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * batch_input.shape[0]

        avg_loss = total_loss / num_chunks
        perplexity = np.exp(avg_loss)
        print("Epoch %d: avg loss = %.4f, train perplexity = %.2f" % (epoch, avg_loss, perplexity))

    model.eval()
    return NeuralLanguageModel(model, vocab_index, chunk_size)
